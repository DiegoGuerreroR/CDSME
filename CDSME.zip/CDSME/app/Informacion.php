<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Informacion extends Model
{
    
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'informacions';

    /**
    * The database primary key value.
    *
    * @var string
    */
    protected $primaryKey = 'id';

    /**
     * Attributes that should be mass-assignable.
     *
     * @var array
     */
    protected $fillable = ['cct', 'nombreEscuela', 'telefono', 'municipio', 'localidad', 'correo'];

    public function escuelas(){
        return $this->hasMany(Escuela::class);
    }
    public function aulas(){
        return $this->hasMany(Aula::class);
    }
    public function dispositivos(){
        return $this->hasMany(Dispositivo::class);
    }
}
