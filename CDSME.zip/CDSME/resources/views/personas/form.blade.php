<div class="form-group">
    <label for="">CCT</label>
    <select name="id" id="id" class="form-control">
    <option value="">-- Elegir CCT ---</option>
    @foreach($item as $item)

        <option value="{{ $item['id'] }}">{{ $item['cct'] }}</option>

    @endforeach
    </select>
</div>

<div class="form-group {{ $errors->has('nombre') ? 'has-error' : ''}}">
    <label for="nombre" class="control-label">{{ 'Nombre' }}</label>
    <input class="form-control" name="nombre" type="text" id="nombre" value="{{ isset($persona->nombre) ? $persona->nombre : ''}}" placeholder="Ingeresa Nombre de la Persona" >
    {!! $errors->first('nombre', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('capacitacion') ? 'has-error' : ''}}">
    <label for="capacitacion" class="control-label">{{ 'Capacitacion' }}</label>
    <input class="form-control" name="capacitacion" type="text" id="capacitacion" value="{{ isset($persona->capacitacion) ? $persona->capacitacion : ''}}" placeholder="Ingeresa Capacitacion" >
    {!! $errors->first('capacitacion', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('fechaCapacitacion') ? 'has-error' : ''}}">
    <label for="fechaCapacitacion" class="control-label">{{ 'Fecha Capacitacion' }}</label>
    <input class="form-control" name="fechaCapacitacion" type="date" id="fechaCapacitacion" value="{{ isset($persona->fechaCapacitacion) ? $persona->fechaCapacitacion : ''}}"  >
    {!! $errors->first('fechaCapacitacion', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('descripcion') ? 'has-error' : ''}}">
    <label for="descripcion" class="control-label">{{ 'Descripcion' }}</label>
    <input class="form-control" name="descripcion" type="text" id="descripcion" value="{{ isset($persona->descripcion) ? $persona->descripcion : ''}}" placeholder="Ingeresa Descripcion" >
    {!! $errors->first('descripcion', '<p class="help-block">:message</p>') !!}
</div>


<div class="form-group">
    <input class="btn btn-primary" type="submit" value="{{ $formMode === 'edit' ? 'Update' : 'Create' }}">
</div>
