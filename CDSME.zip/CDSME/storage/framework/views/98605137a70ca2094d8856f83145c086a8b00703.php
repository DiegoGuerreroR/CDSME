<div class="form-group">
    <label for="">CCT</label>
    <select name="id" id="id" class="form-control">
    <option value="">-- Elegir CCT ---</option>
    <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <option value="<?php echo e($item['id']); ?>"><?php echo e($item['cct']); ?></option>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<div class="form-group <?php echo e($errors->has('fechaSolicitud') ? 'has-error' : ''); ?>">
    <label for="fechaSolicitud" class="control-label"><?php echo e('Fecha Solicitud'); ?></label>
    <input class="form-control" name="fechaSolicitud" type="date" id="fechaSolicitud" value="<?php echo e(isset($aula->fechaSolicitud) ? $aula->fechaSolicitud : ''); ?>" placeholder="Ingeresa Fecha de Solicitud" >
    <?php echo $errors->first('fechaSolicitud', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('fechaRehabilitacion') ? 'has-error' : ''); ?>">
    <label for="fechaRehabilitacion" class="control-label"><?php echo e('Fecha Rehabilitacion'); ?></label>
    <input class="form-control" name="fechaRehabilitacion" type="date" id="fechaRehabilitacion" value="<?php echo e(isset($aula->fechaRehabilitacion) ? $aula->fechaRehabilitacion : ''); ?>" placeholder="Ingeresa Fecha de la Rehabilitacion" >
    <?php echo $errors->first('fechaRehabilitacion', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('estatus') ? 'has-error' : ''); ?>">
    <label for="estatus" class="control-label"><?php echo e('Estatus'); ?></label>
    <input class="form-control" name="estatus" type="text" id="estatus" value="<?php echo e(isset($aula->estatus) ? $aula->estatus : ''); ?>" placeholder="Ingeresa Estatus" >
    <?php echo $errors->first('estatus', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('descripcion') ? 'has-error' : ''); ?>">
    <label for="descripcion" class="control-label"><?php echo e('Descripcion'); ?></label>
    <input class="form-control" name="descripcion" type="text" id="descripcion" value="<?php echo e(isset($aula->descripcion) ? $aula->descripcion : ''); ?>" placeholder="Ingeresa Descripcion" >
    <?php echo $errors->first('descripcion', '<p class="help-block">:message</p>'); ?>

</div>


<div class="form-group">
    <input class="btn btn-primary" type="submit" value="<?php echo e($formMode === 'edit' ? 'Update' : 'Create'); ?>">
</div>
