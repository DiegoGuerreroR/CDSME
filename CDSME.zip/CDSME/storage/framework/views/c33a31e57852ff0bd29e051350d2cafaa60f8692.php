<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <?php echo $__env->make('admin.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="col-md-9">
                <div class="card">
                    <div class="card-header">Persona <?php echo e($persona->id); ?></div>
                    <div class="card-body">

                        <a href="<?php echo e(url('/personas')); ?>" title="Back"><button class="btn btn-warning btn-sm"><i class="fa fa-arrow-left" aria-hidden="true"></i>Regresar</button></a>
                        <a href="<?php echo e(url('/personas/' . $persona->id . '/edit')); ?>" title="Edit Persona"><button class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i>Actualizar</button></a>

                        <form method="POST" action="<?php echo e(url('personas' . '/' . $persona->id)); ?>" accept-charset="UTF-8" style="display:inline">
                            <?php echo e(method_field('DELETE')); ?>

                            <?php echo e(csrf_field()); ?>

                            <button type="submit" class="btn btn-danger btn-sm" title="Delete Persona" onclick="return confirm(&quot;Confirm delete?&quot;)"><i class="fa fa-trash-o" aria-hidden="true"></i>Eliminar</button>
                        </form>
                        <br/>
                        <br/>

                        <div class="table-responsive">
                            <table class="table">
                                <tbody>
                                    <tr>
                                        <th>ID</th><td><?php echo e($persona->id); ?></td>
                                    
                                    </tr>
                                    <tr><th> CCT </th><td> <?php echo e($persona->cct); ?> </td></tr>
                                    <tr><th> NOMBRE </th><td> <?php echo e($persona->nombre); ?> </td></tr>
                                    <tr><th> CAPACITACION </th><td> <?php echo e($persona->capacitacion); ?> </td></tr>
                                    <tr><th> FECHA CAPACITACION </th><td> <?php echo e($persona->fechaCapacitacion); ?> </td></tr>
                                    <tr><th> DESCRIPCION </th><td> <?php echo e($persona->descripcion); ?> </td></tr>
                                    
                                    
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>