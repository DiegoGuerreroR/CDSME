<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateEscuelasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('escuelas', function (Blueprint $table) {
            $table->increments('id');
            $table->string('cct');
            $table->string('fecha')->nullable();
            $table->string('valoracion')->nullable();
            $table->string('descripcion')->nullable();
            $table->timestamps();
            $table->integer('informacion_id')->unsigned();

            $table->foreign('informacion_id')->references('id')->on('informacions');
            });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('escuelas');
    }
}
