<div class="form-group <?php echo e($errors->has('cct') ? 'has-error' : ''); ?>">
    <label for="cct" class="control-label"><?php echo e('cct'); ?></label>
    <input class="form-control" name="cct" type="text" id="cct" value="<?php echo e(isset($dispositivo->cct) ? $dispositivo->cct : ''); ?>" placeholder="Ingeresa CCT" >
    <?php echo $errors->first('cct', '<p class="help-block">:message</p>'); ?>

</div>

<div class="form-group <?php echo e($errors->has('dispositivo') ? 'has-error' : ''); ?>">
    <label for="dispositivo" class="control-label"><?php echo e('Dispositivo'); ?></label>
    <!--<input class="form-control" name="dispositivo" type="text" id="dispositivo" value="<?php echo e(isset($aula->estatus) ? $aula->estatus : ''); ?>" placeholder="Ingeresa Dispositivo" >-->
    <select class="form-control" name="dispositivo" placeholder="Ingeresa Dispositivo" id="dispositivo"  type="text" value="<?php echo e(isset($dispositivo->dispositivo) ? $dispositivo->dispositivo : ''); ?>">
    <option >-- Elegir Dispositivo ---</option>
    <option value="Tablet">Tablet</option>
    <option value="CPU">CPU</option>
    <option value="Computadora">Computadora</option>
    <option value="Cañon">Cañon</option>
    <option value="Impresoras">Impresoras</option>
    <option value="Monitor">Monitor</option>
    <option value="Pizarra Electronica">Pizarra Electronica</option>
    <option value="Sistemas de Conectividad">Sistemas de Conectividad</option>
    <option value="Laptop">Laptop</option>
    <option value="Accesorios de Programa">Accesorios de Programa</option>
    </select>
    <?php echo $errors->first('dispositivo', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('modelo') ? 'has-error' : ''); ?>">
    <label for="modelo" class="control-label"><?php echo e('Modelo'); ?></label>
    <input class="form-control" name="modelo" type="text" id="modelo" value="<?php echo e(isset($dispositivo->modelo) ? $dispositivo->modelo : ''); ?>" placeholder="Ingeresa Modelo" >
    <?php echo $errors->first('modelo', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('estatus') ? 'has-error' : ''); ?>">
    <label for="estatus" class="control-label"><?php echo e('Estatus'); ?></label>
    <!--<input class="form-control" name="estatus" type="text" id="estatus" value="<?php echo e(isset($aula->estatus) ? $aula->estatus : ''); ?>" placeholder="Ingeresa Estatus" >-->
    <select class="form-control" name="estatus" placeholder="Ingeresa Estatus" id="estatus"  type="text" value="<?php echo e(isset($dispositivo->estatus) ? $dispositivo->estatus : ''); ?>">
    <option >-- Elegir Estatus ---</option>
    <option value="Pendiente">Pendiente</option>
    <option value="Realizado">Relizado</option>
    </select>
    <?php echo $errors->first('estatus', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('fechaEntrada') ? 'has-error' : ''); ?>">
    <label for="fechaEntrada" class="control-label"><?php echo e('Fecha Entrada'); ?></label>
    <input class="form-control" name="fechaEntrada" type="date" id="fechaEntrada" value="<?php echo e(isset($dispositivo->fechaEntrada) ? $dispositivo->fechaEntrada : ''); ?>" placeholder="Ingeresa Fecha de Entrada" >
    <?php echo $errors->first('fechaEntrada', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('fechaSalida') ? 'has-error' : ''); ?>">
    <label for="fechaSalida" class="control-label"><?php echo e('Fecha Salida'); ?></label>
    <input class="form-control" name="fechaSalida" type="date" id="fechaSalida" value="<?php echo e(isset($dispositivo->fechaSalida) ? $dispositivo->fechaSalida : ''); ?>" placeholder="Ingeresa Fecha de Salida" >
    <?php echo $errors->first('fechaSalida', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('descripcion') ? 'has-error' : ''); ?>">
    <label for="descripcion" class="control-label"><?php echo e('Descripcion'); ?></label>
    <input class="form-control" name="descripcion" type="text" id="descripcion" value="<?php echo e(isset($dispositivo->descripcion) ? $dispositivo->descripcion : ''); ?>" placeholder="Ingeresa Descricpion" >
    <?php echo $errors->first('descripcion', '<p class="help-block">:message</p>'); ?>

</div>


<div class="form-group">
    <input class="btn btn-primary" type="submit" value="<?php echo e($formMode === 'edit' ? 'Update' : 'Create'); ?>">
</div>
