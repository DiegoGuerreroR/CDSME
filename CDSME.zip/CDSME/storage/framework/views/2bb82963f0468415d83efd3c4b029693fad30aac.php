<div class="form-group <?php echo e($errors->has('cct') ? 'has-error' : ''); ?>">
    <label for="cct" class="control-label"><?php echo e('Cct'); ?></label>
    <input class="form-control" name="cct" type="text" id="cct" value="<?php echo e(isset($persona->cct) ? $persona->cct : ''); ?>" placeholder="Ingeresa CCT" required autofocus>
    <?php echo $errors->first('cct', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('nombre') ? 'has-error' : ''); ?>">
    <label for="nombre" class="control-label"><?php echo e('Nombre'); ?></label>
    <input class="form-control" name="nombre" type="text" id="nombre" value="<?php echo e(isset($persona->nombre) ? $persona->nombre : ''); ?>" placeholder="Ingeresa Nombre de la Persona" >
    <?php echo $errors->first('nombre', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('capacitacion') ? 'has-error' : ''); ?>">
    <label for="capacitacion" class="control-label"><?php echo e('Capacitacion'); ?></label>
    <input class="form-control" name="capacitacion" type="text" id="capacitacion" value="<?php echo e(isset($persona->capacitacion) ? $persona->capacitacion : ''); ?>" placeholder="Ingeresa Capacitacion" >
    <?php echo $errors->first('capacitacion', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('fechaCapacitacion') ? 'has-error' : ''); ?>">
    <label for="fechaCapacitacion" class="control-label"><?php echo e('Fecha Capacitacion'); ?></label>
    <input class="form-control" name="fechaCapacitacion" type="date" id="fechaCapacitacion" value="<?php echo e(isset($persona->fechaCapacitacion) ? $persona->fechaCapacitacion : ''); ?>"  >
    <?php echo $errors->first('fechaCapacitacion', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('descripcion') ? 'has-error' : ''); ?>">
    <label for="descripcion" class="control-label"><?php echo e('Descripcion'); ?></label>
    <input class="form-control" name="descripcion" type="text" id="descripcion" value="<?php echo e(isset($persona->descripcion) ? $persona->descripcion : ''); ?>" placeholder="Ingeresa Descripcion" >
    <?php echo $errors->first('descripcion', '<p class="help-block">:message</p>'); ?>

</div>


<div class="form-group">
    <input class="btn btn-primary" type="submit" value="<?php echo e($formMode === 'edit' ? 'Update' : 'Create'); ?>">
</div>
