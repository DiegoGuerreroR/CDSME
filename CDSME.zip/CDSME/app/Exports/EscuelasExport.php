<?php

namespace App\Exports;

use App\Escuela;
use Maatwebsite\Excel\Concerns\FromCollection;

class EscuelasExport implements FromCollection
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        return Escuela::select("id", "cct", "fecha", "valoracion", "descripcion", "informacion_id")->get();
    }
}
