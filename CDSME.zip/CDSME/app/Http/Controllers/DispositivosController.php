<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\Informacion;
use App\Dispositivo;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Barryvdh\DomPDF\Facade as PDF;

class DispositivosController extends Controller
{

     //Esta funcion es la que da seguridad a la pagina, 
    //con ella no deja visualizarla a menos que este logueado.
    public function __construct()
    {
        $this->middleware('auth');
    }

    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
        $keyword = $request->get('search');
        $perPage = 25;

        if (!empty($keyword)) {
            $dispositivos = Dispositivo::where('dispositivo', 'LIKE', "%$keyword%")
                ->orWhere('modelo', 'LIKE', "%$keyword%")
                ->orWhere('estatus', 'LIKE', "%$keyword%")
                ->orWhere('fechaEntrada', 'LIKE', "%$keyword%")
                ->orWhere('fechaSalida', 'LIKE', "%$keyword%")
                ->orWhere('descripcion', 'LIKE', "%$keyword%")
                ->orWhere('cct', 'LIKE', "%$keyword%")
                ->latest()->paginate($perPage);
        } else {
            $dispositivos = Dispositivo::latest()->paginate($perPage);
        }

        return view('dispositivos.index', compact('dispositivos'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {
        $item = Informacion::all();
        return view('dispositivos.create', compact('item'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function store(Request $request)
    {
        
        $requestData = $request->all();
        $id=Auth::user()->id;
        $requestData['informacion_id']=$id;
        Dispositivo::create($requestData);

        return redirect('dispositivos')->with('flash_message', 'Dispositivo added!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function show($id)
    {
        $dispositivo = Dispositivo::findOrFail($id);

        return view('dispositivos.show', compact('dispositivo'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function edit($id)
    {
        $dispositivo = Dispositivo::findOrFail($id);

        return view('dispositivos.edit', compact('dispositivo'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function update(Request $request, $id)
    {
        
        $requestData = $request->all();
        
        $dispositivo = Dispositivo::findOrFail($id);
        $dispositivo->update($requestData);

        return redirect('dispositivos')->with('flash_message', 'Dispositivo updated!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function destroy($id)
    {
        Dispositivo::destroy($id);

        return redirect('dispositivos')->with('flash_message', 'Dispositivo deleted!');
    }
    public function exportPdf()
    {
        $dispositivos = Dispositivo::get();
        $pdf = PDF::loadView('pdf.dispositivos', compact('dispositivos'));

        return $pdf->download('dispositivos-list.pdf');
    }
}
