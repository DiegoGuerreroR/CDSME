<div class="form-group <?php echo e($errors->has('cct') ? 'has-error' : ''); ?>">
    <label for="cct" class="control-label"><?php echo e('Cct'); ?></label>
    <input class="form-control" name="cct" type="text" id="cct" value="<?php echo e(isset($informacion->cct) ? $informacion->cct : ''); ?>" >
    <?php echo $errors->first('cct', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('nombreEscuela') ? 'has-error' : ''); ?>">
    <label for="nombreEscuela" class="control-label"><?php echo e('Nombre Escuela'); ?></label>
    <input class="form-control" name="nombreEscuela" type="text" id="nombreEscuela" value="<?php echo e(isset($informacion->nombreEscuela) ? $informacion->nombreEscuela : ''); ?>" placeholder="Ingeresa Nombre de la Escuela" >
    <?php echo $errors->first('nombreEscuela', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('telefono') ? 'has-error' : ''); ?>">
    <label for="telefono" class="control-label"><?php echo e('Telefono'); ?></label>
    <input class="form-control" name="telefono" type="text" id="telefono" value="<?php echo e(isset($informacion->telefono) ? $informacion->telefono : ''); ?>" placeholder="Ingeresa Telefono" >
    <?php echo $errors->first('telefono', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('municipio') ? 'has-error' : ''); ?>">
    <label for="municipio" class="control-label"><?php echo e('Municipio'); ?></label>
    <input class="form-control" name="municipio" type="text" id="municipio" value="<?php echo e(isset($informacion->municipio) ? $informacion->municipio : ''); ?>" placeholder="Ingeresa Municipio">
    <?php echo $errors->first('municipio', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('localidad') ? 'has-error' : ''); ?>">
    <label for="localidad" class="control-label"><?php echo e('Localidad'); ?></label>
    <input class="form-control" name="localidad" type="text" id="localidad" value="<?php echo e(isset($informacion->localidad) ? $informacion->localidad : ''); ?>" placeholder="Ingeresa Localidad" >
    <?php echo $errors->first('localidad', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('correo') ? 'has-error' : ''); ?>">
    <label for="correo" class="control-label"><?php echo e('Correo'); ?></label>
    <input class="form-control" name="correo" type="email" id="correo" value="<?php echo e(isset($informacion->correo) ? $informacion->correo : ''); ?>" placeholder="Ingeresa Correo" >
    <?php echo $errors->first('correo', '<p class="help-block">:message</p>'); ?>

</div>


<div class="form-group">
    <input class="btn btn-primary" type="submit" value="<?php echo e($formMode === 'edit' ? 'Update' : 'Create'); ?>">
</div>
