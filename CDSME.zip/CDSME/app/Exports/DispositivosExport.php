<?php

namespace App\Exports;

use App\Dispositivo;
use Maatwebsite\Excel\Concerns\FromCollection;

class DispositivosExport implements FromCollection
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        return Dispositivo::select("id", "cct", "dispositivo", "modelo", "estatus", "fechaEntrada", "fechaSalida", "descripcion", "informacion_id")->get();
    }
}
