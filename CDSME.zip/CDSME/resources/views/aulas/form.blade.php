<div class="form-group">
    <label for="">CCT</label>
    <select name="id" id="id" class="form-control">
    <option value="">-- Elegir CCT ---</option>
    @foreach($item as $item)

        <option value="{{ $item['id'] }}">{{ $item['cct'] }}</option>

    @endforeach
    </select>
</div>

<div class="form-group {{ $errors->has('fechaSolicitud') ? 'has-error' : ''}}">
    <label for="fechaSolicitud" class="control-label">{{ 'Fecha Solicitud' }}</label>
    <input class="form-control" name="fechaSolicitud" type="date" id="fechaSolicitud" value="{{ isset($aula->fechaSolicitud) ? $aula->fechaSolicitud : ''}}" placeholder="Ingeresa Fecha de Solicitud" >
    {!! $errors->first('fechaSolicitud', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('fechaRehabilitacion') ? 'has-error' : ''}}">
    <label for="fechaRehabilitacion" class="control-label">{{ 'Fecha Rehabilitacion' }}</label>
    <input class="form-control" name="fechaRehabilitacion" type="date" id="fechaRehabilitacion" value="{{ isset($aula->fechaRehabilitacion) ? $aula->fechaRehabilitacion : ''}}" placeholder="Ingeresa Fecha de la Rehabilitacion" >
    {!! $errors->first('fechaRehabilitacion', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('estatus') ? 'has-error' : ''}}">
    <label for="estatus" class="control-label">{{ 'Estatus' }}</label>
    <input class="form-control" name="estatus" type="text" id="estatus" value="{{ isset($aula->estatus) ? $aula->estatus : ''}}" placeholder="Ingeresa Estatus" >
    {!! $errors->first('estatus', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('descripcion') ? 'has-error' : ''}}">
    <label for="descripcion" class="control-label">{{ 'Descripcion' }}</label>
    <input class="form-control" name="descripcion" type="text" id="descripcion" value="{{ isset($aula->descripcion) ? $aula->descripcion : ''}}" placeholder="Ingeresa Descripcion" >
    {!! $errors->first('descripcion', '<p class="help-block">:message</p>') !!}
</div>


<div class="form-group">
    <input class="btn btn-primary" type="submit" value="{{ $formMode === 'edit' ? 'Update' : 'Create' }}">
</div>
