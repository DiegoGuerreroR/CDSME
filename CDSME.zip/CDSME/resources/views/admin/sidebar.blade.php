<div class="col-md-3">
    <div class="card">
        <div class="card-header">
            Menu
        </div>

        <div class="card-body">
            <ul class="nav" role="tablist">
                <li role="presentation">
                <a href="{{ url('/informacion') }}">
                        Informacion
                    </a>
                    <a href="{{ url('/actividades') }}">
                        Actividades
                    </a>
                    <a href="{{ url('/aulas') }}">
                        Aulas
                    </a>
                    <a href="{{ url('/dispositivos') }}">
                        Dispositivos
                    </a>
                    <a href="{{ url('/escuelas') }}">
                        Escuelas
                    </a>
                    <a href="{{ url('/personas') }}">
                        Personas
                    </a>
                </li>
            </ul>
        </div>
    </div>
</div>
