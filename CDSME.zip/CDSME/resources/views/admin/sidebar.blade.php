<div class="col-md-3">
    <div class="card">
        <div class="card-header">
            Menu
        </div>

        <div class="card-body">
            <ul class="nav" role="tablist">
                <li role="presentation">
                <a href="{{ url('/informacion') }}">
                        Informacion
                    </a>
                    <br>
                    <a href="{{ url('/actividades') }}">
                        Actividades
                    </a>
                    <br>
                    <a href="{{ url('/aulas') }}">
                        Aulas
                    </a>
                    <br>
                    <a href="{{ url('/dispositivos') }}">
                        Dispositivos
                    </a>
                    <br>
                    <a href="{{ url('/escuelas') }}">
                        Escuelas
                    </a>
                    <br>
                    <a href="{{ url('/personas') }}">
                        Personas
                    </a>
                </li>
            </ul>
        </div>
    </div>
</div>
