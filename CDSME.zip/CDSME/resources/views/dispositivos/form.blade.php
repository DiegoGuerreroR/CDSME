<div class="form-group {{ $errors->has('cct') ? 'has-error' : ''}}">
    <label for="cct" class="control-label">{{ 'cct' }}</label>
    <input class="form-control" name="cct" type="text" id="cct" value="{{ isset($dispositivo->cct) ? $dispositivo->cct : ''}}" placeholder="Ingeresa CCT" required autofocus >
    {!! $errors->first('cct', '<p class="help-block">:message</p>') !!}
</div>

<div class="form-group {{ $errors->has('dispositivo') ? 'has-error' : ''}}">
    <label for="dispositivo" class="control-label">{{ 'Dispositivo' }}</label>
    <!--<input class="form-control" name="dispositivo" type="text" id="dispositivo" value="{{ isset($aula->estatus) ? $aula->estatus : ''}}" placeholder="Ingeresa Dispositivo" >-->
    <select class="form-control" name="dispositivo" placeholder="Ingeresa Dispositivo" id="dispositivo"  type="text" value="{{ isset($dispositivo->dispositivo) ? $dispositivo->dispositivo : ''}}">
    <option >-- Elegir Dispositivo ---</option>
    <option value="Tablet">Tablet</option>
    <option value="CPU">CPU</option>
    <option value="Computadora">Computadora</option>
    <option value="Cañon">Cañon</option>
    <option value="Impresoras">Impresoras</option>
    <option value="Monitor">Monitor</option>
    <option value="Pizarra Electronica">Pizarra Electronica</option>
    <option value="Sistemas de Conectividad">Sistemas de Conectividad</option>
    <option value="Laptop">Laptop</option>
    <option value="Accesorios de Programa">Accesorios de Programa</option>
    </select>
    {!! $errors->first('dispositivo', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('modelo') ? 'has-error' : ''}}">
    <label for="modelo" class="control-label">{{ 'Modelo' }}</label>
    <input class="form-control" name="modelo" type="text" id="modelo" value="{{ isset($dispositivo->modelo) ? $dispositivo->modelo : ''}}" placeholder="Ingeresa Modelo" >
    {!! $errors->first('modelo', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('estatus') ? 'has-error' : ''}}">
    <label for="estatus" class="control-label">{{ 'Estatus' }}</label>
    <!--<input class="form-control" name="estatus" type="text" id="estatus" value="{{ isset($aula->estatus) ? $aula->estatus : ''}}" placeholder="Ingeresa Estatus" >-->
    <select class="form-control" name="estatus" placeholder="Ingeresa Estatus" id="estatus"  type="text" value="{{ isset($dispositivo->estatus) ? $dispositivo->estatus : ''}}">
    <option >-- Elegir Estatus ---</option>
    <option class="p-3 mb-2 bg-success text-white" value="Pendiente">Pendiente</option>
    <option class="p-3 mb-2 bg-danger text-white" value="Realizado">Relizado</option>
    </select>
    {!! $errors->first('estatus', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('fechaEntrada') ? 'has-error' : ''}}">
    <label for="fechaEntrada" class="control-label">{{ 'Fecha Entrada' }}</label>
    <input class="form-control" name="fechaEntrada" type="date" id="fechaEntrada" value="{{ isset($dispositivo->fechaEntrada) ? $dispositivo->fechaEntrada : ''}}" placeholder="Ingeresa Fecha de Entrada" >
    {!! $errors->first('fechaEntrada', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('fechaSalida') ? 'has-error' : ''}}">
    <label for="fechaSalida" class="control-label">{{ 'Fecha Salida' }}</label>
    <input class="form-control" name="fechaSalida" type="date" id="fechaSalida" value="{{ isset($dispositivo->fechaSalida) ? $dispositivo->fechaSalida : ''}}" placeholder="Ingeresa Fecha de Salida" >
    {!! $errors->first('fechaSalida', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('descripcion') ? 'has-error' : ''}}">
    <label for="descripcion" class="control-label">{{ 'Descripcion' }}</label>
    <input class="form-control" name="descripcion" type="text" id="descripcion" value="{{ isset($dispositivo->descripcion) ? $dispositivo->descripcion : ''}}" placeholder="Ingeresa Descricpion" >
    {!! $errors->first('descripcion', '<p class="help-block">:message</p>') !!}
</div>


<div class="form-group">
    <input class="btn btn-primary" type="submit" value="{{ $formMode === 'edit' ? 'Update' : 'Create' }}">
</div>
