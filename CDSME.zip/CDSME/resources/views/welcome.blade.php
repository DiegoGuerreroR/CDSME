<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Centro Estatal De Tecnologias Eduacativas</title>
<!--Estilo de la pagina principal-->
        <style>
          * {
            box-sizing: border-box;
            font-family: Arial, Helvetica, sans-serif;
          }

          body {
            margin: ;
            font-family: Arial, Helvetica, sans-serif;
          }

          /* Style the top navigation bar */
          .topnav {
            overflow: hidden;
            background-color: #960000;
          }

          /* Style de la barra de encabezado */
          .topnav a {
            float: right;
            display: block;
            color: #f2f2f2;
            text-align: center;
            padding: 5px 10px;
            text-decoration: none;
          }

          /* Change color on hover */
          .topnav a:hover {
            background-color: #ddd;
            color: black;
          }

          /* Style del contenido */
          .content {
            background-color: #ffffff;
            padding: 10px;
            height: 800px; /* Should be removed. Only for demonstration */
          }

          /* Style del pie de la pagina */
          .footer {
            background-color: #960000;
            padding: 10px;
          }
    </style>
</head>
<body>
<div class="topnav">
<img src="http://www.seduzac.gob.mx/portal/img/Logo-header.png">
<p>
<button style="text-align: right;width:100px left;width:100px" style="height:40px; width:100px;" href="{{ route('login') }}" type="button" class="btn btn-outline-secondary" data-toggle="modal" data-target="#exampleModal" data-whatever="@fat">Ingresar</button>

<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
    <div class="form-group">
            <br>
            <label for="text" class="col-md-4">Inicio de sesion</label>
            <div class="panel-body">
                    <form class="form-horizontal" method="POST" action="{{ route('login') }}">
                        {{ csrf_field() }}

                        <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                            <label for="email" class="col-md-4 control-label">Usuario</label>

                            <div class="col-md-11">
                                <input id="email" type="email" class="form-control" name="email" value="{{ old('email') }}" required autofocus>

                                @if ($errors->has('email'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                            <label for="password" class="col-md-4 control-label">Contraseña</label>

                            <div class="col-md-11">
                                <input id="password" type="password" class="form-control" name="password" required>

                                @if ($errors->has('password'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                @endif
                            </div>
                            <div>
                            <br>
                            <div class="form-group">
                            <div class="col-md-8 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Acceder
                                </button>
                        </div>
                        </div>
                        </div>
                        </div>
          </div>
        </form>
      </div>
      </div>
      </div>
<!--@if (Route::has('login'))

                <div class="top-right links">
                    @auth
                        <a href="{{ url('/home') }}">Home</a>
                    @else
                        <a href="{{ route('register') }}">Register</a>
                        <a href="{{ route('login') }}">Login</a>
                    @endauth
                </div>
            @endif-->
 
</div>
<div class="flex-center position-ref full-height">
<div class="content">
<div class="title m-b-md">
        Centro Estatal de Tecnologias Educativas
        <br>
        Sistema de Captura de Reportes de Actividades
</div>
</div>

<div class="footer">

  <p><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3679.2061370066017!2d-102.5360768340394!3d22.75773006339422!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14075c599f8c7adb%3A0xbc8951011b8d0791!2sCENTRO+ESTATAL+DE+TECNOLOGIA+EDUCATIVA+Centro+Comunitario+Digital!5e0!3m2!1ses-419!2smx!4v1562769168389!5m2!1ses-419!2smx" width="400" height="300" frameborder="0" style="border:0" allowfullscreen></iframe></p>
</div>

</head>
<body>

</body>
</html>


<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
