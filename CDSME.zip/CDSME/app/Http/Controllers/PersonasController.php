<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\Informacion;
use App\Persona;
use Illuminate\Http\Request;

class PersonasController extends Controller
{

     //Esta funcion es la que da seguridad a la pagina, 
    //con ella no deja visualizarla a menos que este logueado.
    /*public function __construct()
    {
        $this->middleware('auth');
    }*/

    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
        $keyword = $request->get('search');
        $perPage = 25;

        if (!empty($keyword)) {
            $personas = Persona::where('nombre', 'LIKE', "%$keyword%")
                ->orWhere('capacitacion', 'LIKE', "%$keyword%")
                ->orWhere('fechaCapacitacion', 'LIKE', "%$keyword%")
                ->orWhere('descripcion', 'LIKE', "%$keyword%")
                ->orWhere('cct', 'LIKE', "%$keyword%")
                ->latest()->paginate($perPage);
        } else {
            $personas = Persona::latest()->paginate($perPage);
        }

        return view('personas.index', compact('personas'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {
        $item = Informacion::all();
        return view('personas.create', compact('item'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function store(Request $request)
    {
        
        $requestData = $request->all();
        
        Persona::create($requestData);

        return redirect('personas')->with('flash_message', 'Persona added!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function show($id)
    {
        $persona = Persona::findOrFail($id);

        return view('personas.show', compact('persona'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function edit($id)
    {
        $persona = Persona::findOrFail($id);

        return view('personas.edit', compact('persona'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function update(Request $request, $id)
    {
        
        $requestData = $request->all();
        
        $persona = Persona::findOrFail($id);
        $persona->update($requestData);

        return redirect('personas')->with('flash_message', 'Persona updated!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function destroy($id)
    {
        Persona::destroy($id);

        return redirect('personas')->with('flash_message', 'Persona deleted!');
    }
}
