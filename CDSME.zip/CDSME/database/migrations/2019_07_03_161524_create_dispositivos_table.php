<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateDispositivosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('dispositivos', function (Blueprint $table) {
            $table->increments('id');
            $table->string('cct');
            $table->string('dispositivo')->nullable();
            $table->string('modelo')->nullable();
            $table->string('estatus')->nullable();
            $table->string('fechaEntrada')->nullable();
            $table->string('fechaSalida')->nullable();
            $table->string('descripcion')->nullable();
            $table->timestamps();
            $table->integer('informacion_id')->unsigned();

            $table->foreign('informacion_id')->references('id')->on('informacions');
            });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('dispositivos');
    }
}
