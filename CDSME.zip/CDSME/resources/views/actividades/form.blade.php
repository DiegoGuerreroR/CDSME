<div class="form-group">
    <label for="">CCT</label>
    <select name="id" id="id" class="form-control" name="cct" type="text" id="cct" value="{{ isset($actividade->cct) ? $actividade->cct : ''}}">
    <option value="">-- Elegir CCT ---</option>
    @foreach($item as $item)

        <option value="{{ $item['id'] }}">{{ $item['cct'] }}</option>
        

    @endforeach
    </select>
    
</div>

<!--<div class="form-group {{ $errors->has('cct') ? 'has-error' : ''}}">
    <label for="fecha" class="control-label">{{ 'cct' }}</label>
    <input class="form-control" name="cct" type="text" id="cct" value="{{ isset($actividade->cct) ? $actividade->cct : ''}}" placeholder="Ingeresa cct" >
    {!! $errors->first('cct', '<p class="help-block">:message</p>') !!}
</div>-->

<div class="form-group {{ $errors->has('fecha') ? 'has-error' : ''}}">
    <label for="fecha" class="control-label">{{ 'Fecha' }}</label>
    <input class="form-control" name="fecha" type="date" id="fecha" value="{{ isset($actividade->fecha) ? $actividade->fecha : ''}}" placeholder="Ingeresa Fecha" >
    {!! $errors->first('fecha', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('actividad') ? 'has-error' : ''}}">
    <label for="actividad" class="control-label">{{ 'Actividad' }}</label>
    <input class="form-control" name="actividad" type="text" id="actividad" value="{{ isset($actividade->actividad) ? $actividade->actividad : ''}}" placeholder="Ingeresa Actividad" >
    {!! $errors->first('actividad', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group">
    <input class="btn btn-primary" type="submit" value="{{ $formMode === 'edit' ? 'Update' : 'Create' }}">
</div>
