<div class="form-group {{ $errors->has('dispositivo') ? 'has-error' : ''}}">
    <label for="dispositivo" class="control-label">{{ 'Dispositivo' }}</label>
    <input class="form-control" name="dispositivo" type="text" id="dispositivo" value="{{ isset($dispositivo->dispositivo) ? $dispositivo->dispositivo : ''}}" >
    {!! $errors->first('dispositivo', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('modelo') ? 'has-error' : ''}}">
    <label for="modelo" class="control-label">{{ 'Modelo' }}</label>
    <input class="form-control" name="modelo" type="text" id="modelo" value="{{ isset($dispositivo->modelo) ? $dispositivo->modelo : ''}}" >
    {!! $errors->first('modelo', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('estatus') ? 'has-error' : ''}}">
    <label for="estatus" class="control-label">{{ 'Estatus' }}</label>
    <input class="form-control" name="estatus" type="text" id="estatus" value="{{ isset($dispositivo->estatus) ? $dispositivo->estatus : ''}}" >
    {!! $errors->first('estatus', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('fechaEntrada') ? 'has-error' : ''}}">
    <label for="fechaEntrada" class="control-label">{{ 'Fechaentrada' }}</label>
    <input class="form-control" name="fechaEntrada" type="text" id="fechaEntrada" value="{{ isset($dispositivo->fechaEntrada) ? $dispositivo->fechaEntrada : ''}}" >
    {!! $errors->first('fechaEntrada', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('fechaSalida') ? 'has-error' : ''}}">
    <label for="fechaSalida" class="control-label">{{ 'Fechasalida' }}</label>
    <input class="form-control" name="fechaSalida" type="text" id="fechaSalida" value="{{ isset($dispositivo->fechaSalida) ? $dispositivo->fechaSalida : ''}}" >
    {!! $errors->first('fechaSalida', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('descripcion') ? 'has-error' : ''}}">
    <label for="descripcion" class="control-label">{{ 'Descripcion' }}</label>
    <input class="form-control" name="descripcion" type="email" id="descripcion" value="{{ isset($dispositivo->descripcion) ? $dispositivo->descripcion : ''}}" >
    {!! $errors->first('descripcion', '<p class="help-block">:message</p>') !!}
</div>


<div class="form-group">
    <input class="btn btn-primary" type="submit" value="{{ $formMode === 'edit' ? 'Update' : 'Create' }}">
</div>
