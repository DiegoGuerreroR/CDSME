<div class="form-group">
    <label for="">CCT</label>
    <select name="id" id="id" class="form-control">
    <option value="">-- Elegir CCT ---</option>
    <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <option value="<?php echo e($item['id']); ?>"><?php echo e($item['cct']); ?></option>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<div class="form-group <?php echo e($errors->has('dispositivo') ? 'has-error' : ''); ?>">
    <label for="dispositivo" class="control-label"><?php echo e('Dispositivo'); ?></label>
    <input class="form-control" name="dispositivo" type="text" id="dispositivo" value="<?php echo e(isset($dispositivo->dispositivo) ? $dispositivo->dispositivo : ''); ?>" placeholder="Ingeresa Dispositivo" >
    <?php echo $errors->first('dispositivo', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('modelo') ? 'has-error' : ''); ?>">
    <label for="modelo" class="control-label"><?php echo e('Modelo'); ?></label>
    <input class="form-control" name="modelo" type="text" id="modelo" value="<?php echo e(isset($dispositivo->modelo) ? $dispositivo->modelo : ''); ?>" placeholder="Ingeresa Modelo" >
    <?php echo $errors->first('modelo', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('estatus') ? 'has-error' : ''); ?>">
    <label for="estatus" class="control-label"><?php echo e('Estatus'); ?></label>
    <input class="form-control" name="estatus" type="text" id="estatus" value="<?php echo e(isset($dispositivo->estatus) ? $dispositivo->estatus : ''); ?>" placeholder="Ingeresa Estatus" >
    <?php echo $errors->first('estatus', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('fechaEntrada') ? 'has-error' : ''); ?>">
    <label for="fechaEntrada" class="control-label"><?php echo e('Fecha Entrada'); ?></label>
    <input class="form-control" name="fechaEntrada" type="date" id="fechaEntrada" value="<?php echo e(isset($dispositivo->fechaEntrada) ? $dispositivo->fechaEntrada : ''); ?>" placeholder="Ingeresa Fecha de Entrada" >
    <?php echo $errors->first('fechaEntrada', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('fechaSalida') ? 'has-error' : ''); ?>">
    <label for="fechaSalida" class="control-label"><?php echo e('Fecha Salida'); ?></label>
    <input class="form-control" name="fechaSalida" type="date" id="fechaSalida" value="<?php echo e(isset($dispositivo->fechaSalida) ? $dispositivo->fechaSalida : ''); ?>" placeholder="Ingeresa Fecha de Salida >
    <?php echo $errors->first('fechaSalida', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('descripcion') ? 'has-error' : ''); ?>">
    <label for="descripcion" class="control-label"><?php echo e('Descripcion'); ?></label>
    <input class="form-control" name="descripcion" type="text" id="descripcion" value="<?php echo e(isset($dispositivo->descripcion) ? $dispositivo->descripcion : ''); ?>" placeholder="Ingeresa Descricpion" >
    <?php echo $errors->first('descripcion', '<p class="help-block">:message</p>'); ?>

</div>


<div class="form-group">
    <input class="btn btn-primary" type="submit" value="<?php echo e($formMode === 'edit' ? 'Update' : 'Create'); ?>">
</div>
