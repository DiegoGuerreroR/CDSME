<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');

});

Route::resource('informacion', 'InformacionController');
Route::resource('escuelas', 'EscuelasController');
Route::resource('dispositivos', 'DispositivosController');
Route::resource('aulas', 'AulasController');
Route::resource('personas', 'PersonasController');
Route::resource('actividades', 'ActividadesController');
Auth::routes();

Route::get('/informacion', 'InformacionController@index')->name('informacion');

Route::get('actividades-list-pdf', 'ActividadesController@exportPdf')->name('actividades.pdf');
Route::get('escuelas-list-pdf', 'EscuelasController@exportPdf')->name('escuelas.pdf');
Route::get('dispositivos-list-pdf', 'DispositivosController@exportPdf')->name('dispositivos.pdf');
Route::get('aulas-list-pdf', 'AulasController@exportPdf')->name('aulas.pdf');
Route::get('personas-list-pdf', 'PersonasController@exportPdf')->name('personas.pdf');

Route::get('actividades-list-excel', 'ActividadesController@index')->name('actividades');
Route::get('descargar-actividades', 'ActividadesController@excel')->name('actividades.excel');