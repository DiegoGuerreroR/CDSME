@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row">
            @include('admin.sidebar')

            <div class="col-md-9">
                <div class="card">
                    <div class="card-header">Aula {{ $aula->id }}</div>
                    <div class="card-body">

                        <a href="{{ url('/aulas') }}" title="Back"><button class="btn btn-warning btn-sm"><i class="fa fa-arrow-left" aria-hidden="true"></i>Regresar</button></a>
                        <a href="{{ url('/aulas/' . $aula->id . '/edit') }}" title="Edit Aula"><button class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i>Editar</button></a>

                        <form method="POST" action="{{ url('aulas' . '/' . $aula->id) }}" accept-charset="UTF-8" style="display:inline">
                            {{ method_field('DELETE') }}
                            {{ csrf_field() }}
                            <button type="submit" class="btn btn-danger btn-sm" title="Delete Aula" onclick="return confirm(&quot;Confirm delete?&quot;)"><i class="fa fa-trash-o" aria-hidden="true"></i>Eliminar</button>
                        </form>
                        <br/>
                        <br/>

                        <div class="table-responsive">
                            <table class="table">
                                <tbody>
                                    <tr>
                                        <th>ID</th><td>{{ $aula->id }}</td>
                                    </tr>
                                    <tr><th> CCT </th><td> {{ $aula->cct }} </td></tr>
                                    <tr><th> FECHA SOLICITUD </th><td> {{ $aula->fechaSolicitud }} </td></tr>
                                    <tr><th> FECHA REHABILITACION </th><td> {{ $aula->fechaRehabilitacion }} </td></tr>
                                    <tr><th> ESTATUS </th><td> {{ $aula->estatus }} </td></tr>
                                    <tr><th> DESCRIPCION </th><td> {{ $aula->descripcion }} </td></tr>
                                    <tr><th> USUARIO </th><td> {{ $aula->informacion_id }} </td></tr>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
