<div class="form-group {{ $errors->has('cct') ? 'has-error' : ''}}">
    <label for="cct" class="control-label">{{ 'Cct' }}</label>
    <input class="form-control" name="cct" type="text" id="cct" value="{{ isset($informacion->cct) ? $informacion->cct : ''}}" >
    {!! $errors->first('cct', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('nombreEscuela') ? 'has-error' : ''}}">
    <label for="nombreEscuela" class="control-label">{{ 'Nombreescuela' }}</label>
    <input class="form-control" name="nombreEscuela" type="text" id="nombreEscuela" value="{{ isset($informacion->nombreEscuela) ? $informacion->nombreEscuela : ''}}" >
    {!! $errors->first('nombreEscuela', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('telefono') ? 'has-error' : ''}}">
    <label for="telefono" class="control-label">{{ 'Telefono' }}</label>
    <input class="form-control" name="telefono" type="text" id="telefono" value="{{ isset($informacion->telefono) ? $informacion->telefono : ''}}" >
    {!! $errors->first('telefono', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('municipio') ? 'has-error' : ''}}">
    <label for="municipio" class="control-label">{{ 'Municipio' }}</label>
    <input class="form-control" name="municipio" type="text" id="municipio" value="{{ isset($informacion->municipio) ? $informacion->municipio : ''}}" >
    {!! $errors->first('municipio', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('localidad') ? 'has-error' : ''}}">
    <label for="localidad" class="control-label">{{ 'Localidad' }}</label>
    <input class="form-control" name="localidad" type="text" id="localidad" value="{{ isset($informacion->localidad) ? $informacion->localidad : ''}}" >
    {!! $errors->first('localidad', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('correo') ? 'has-error' : ''}}">
    <label for="correo" class="control-label">{{ 'Correo' }}</label>
    <input class="form-control" name="correo" type="email" id="correo" value="{{ isset($informacion->correo) ? $informacion->correo : ''}}" >
    {!! $errors->first('correo', '<p class="help-block">:message</p>') !!}
</div>


<div class="form-group">
    <input class="btn btn-primary" type="submit" value="{{ $formMode === 'edit' ? 'Update' : 'Create' }}">
</div>
