<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\Informacion;
use App\Escuela;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Barryvdh\DomPDF\Facade as PDF;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\EscuelasExport;


class EscuelasController extends Controller
{

     //Esta funcion es la que da seguridad a la pagina, 
    //con ella no deja visualizarla a menos que este logueado.
    public function __construct()
    {
        $this->middleware('auth');
    }

    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
        $keyword = $request->get('search');
        $perPage = 25;

        if (!empty($keyword)) {
            $escuelas = Escuela::where('fecha', 'LIKE', "%$keyword%")
                ->orWhere('valoracion', 'LIKE', "%$keyword%")
                ->orWhere('descripcion', 'LIKE', "%$keyword%")
                ->orWhere('cct', 'LIKE', "%$keyword%")
                ->latest()->paginate($perPage);
        } else {
            $escuelas = Escuela::latest()->paginate($perPage);
        }

        return view('escuelas.index', compact('escuelas'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {
        $item = Informacion::all();
        return view('escuelas.create', compact('item'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function store(Request $request)
    {
        
        $requestData = $request->all();
        
        $id=Auth::user()->id;
        $requestData['informacion_id']=$id;
        Escuela::create($requestData);
        
        return redirect('escuelas')->with('flash_message', 'Escuela added!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function show($id)
    {
        $escuela = Escuela::findOrFail($id);

        return view('escuelas.show', compact('escuela'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function edit($id)
    {
        $escuela = Escuela::findOrFail($id);

        return view('escuelas.edit', compact('escuela'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function update(Request $request, $id)
    {
        
        $requestData = $request->all();
        
        $escuela = Escuela::findOrFail($id);
        $escuela->update($requestData);

        return redirect('escuelas')->with('flash_message', 'Escuela updated!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function destroy($id)
    {
        Escuela::destroy($id);

        return redirect('escuelas')->with('flash_message', 'Escuela deleted!');
    }
    public function exportPdf()
    {
        $escuelas = Escuela::get();
        $pdf = PDF::loadView('pdf.escuelas', compact('escuelas'));

        return $pdf->download('escuelas-list.pdf');
    }
    public function exportExcel()
    {
        return Excel::download(new EscuelasExport, 'escuela-list.xlsx');
    }
}
