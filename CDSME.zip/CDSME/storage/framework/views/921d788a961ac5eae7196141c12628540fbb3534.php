<div class="form-group <?php echo e($errors->has('cct') ? 'has-error' : ''); ?>">
    <label for="cct" class="control-label"><?php echo e('cct'); ?></label>
    <input class="form-control" name="cct" type="text" id="cct" value="<?php echo e(isset($escuela->cct) ? $escuela->cct : ''); ?>" placeholder="Ingeresa CCT" required autofocus>
    <?php echo $errors->first('cct', '<p class="help-block">:message</p>'); ?>

</div>

<div class="form-group <?php echo e($errors->has('fecha') ? 'has-error' : ''); ?>">
    <label for="fecha" class="control-label"><?php echo e('Fecha'); ?></label>
    <input class="form-control" name="fecha" type="date" id="fecha" value="<?php echo e(isset($escuela->fecha) ? $escuela->fecha : ''); ?>"  >
    <?php echo $errors->first('fecha', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('valoracion') ? 'has-error' : ''); ?>">
    <label for="valoracion" class="control-label"><?php echo e('Valoracion'); ?></label>
    <input class="form-control" name="valoracion" type="text" id="valoracion" value="<?php echo e(isset($escuela->valoracion) ? $escuela->valoracion : ''); ?>" placeholder="Inserta el tipo de Escuela" >
    <?php echo $errors->first('valoracion', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('descripcion') ? 'has-error' : ''); ?>">
    <label for="descripcion" class="control-label"><?php echo e('Descripcion'); ?></label>
    <input class="form-control" name="descripcion" type="text" id="descripcion" value="<?php echo e(isset($escuela->descripcion) ? $escuela->descripcion : ''); ?>"placeholder="Ingeresa Descripcion" >
    <?php echo $errors->first('descripcion', '<p class="help-block">:message</p>'); ?>

</div>


<div class="form-group">
    <input class="btn btn-primary" type="submit" value="<?php echo e($formMode === 'edit' ? 'Update' : 'Create'); ?>">
</div>
