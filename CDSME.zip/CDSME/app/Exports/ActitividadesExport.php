<?php

namespace App\Exports;

use App\Actividade;
use Maatwebsite\Excel\Concerns\FromCollection;

class ActitividadesExport implements FromCollection
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        return Actividade::select("id", "cct", "fecha", "actividad", "user_id")->get();
    }
}
