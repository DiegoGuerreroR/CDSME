<div class="form-group <?php echo e($errors->has('nombre') ? 'has-error' : ''); ?>">
    <label for="nombre" class="control-label"><?php echo e('Nombre'); ?></label>
    <input class="form-control" name="nombre" type="text" id="nombre" value="<?php echo e(isset($persona->nombre) ? $persona->nombre : ''); ?>" >
    <?php echo $errors->first('nombre', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('capacitacion') ? 'has-error' : ''); ?>">
    <label for="capacitacion" class="control-label"><?php echo e('Capacitacion'); ?></label>
    <input class="form-control" name="capacitacion" type="text" id="capacitacion" value="<?php echo e(isset($persona->capacitacion) ? $persona->capacitacion : ''); ?>" >
    <?php echo $errors->first('capacitacion', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('fechaCapacitacion') ? 'has-error' : ''); ?>">
    <label for="fechaCapacitacion" class="control-label"><?php echo e('Fecha Capacitacion'); ?></label>
    <input class="form-control" name="fechaCapacitacion" type="date" id="fechaCapacitacion" value="<?php echo e(isset($persona->fechaCapacitacion) ? $persona->fechaCapacitacion : ''); ?>" >
    <?php echo $errors->first('fechaCapacitacion', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('descripcion') ? 'has-error' : ''); ?>">
    <label for="descripcion" class="control-label"><?php echo e('Descripcion'); ?></label>
    <input class="form-control" name="descripcion" type="text" id="descripcion" value="<?php echo e(isset($persona->descripcion) ? $persona->descripcion : ''); ?>" >
    <?php echo $errors->first('descripcion', '<p class="help-block">:message</p>'); ?>

</div>


<div class="form-group">
    <input class="btn btn-primary" type="submit" value="<?php echo e($formMode === 'edit' ? 'Update' : 'Create'); ?>">
</div>
