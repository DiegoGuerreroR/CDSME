<div class="form-group {{ $errors->has('capacitacion') ? 'has-error' : ''}}">
    <label for="capacitacion" class="control-label">{{ 'Capacitacion' }}</label>
    <input class="form-control" name="capacitacion" type="text" id="capacitacion" value="{{ isset($persona->capacitacion) ? $persona->capacitacion : ''}}" >
    {!! $errors->first('capacitacion', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('fechaCapacitacion') ? 'has-error' : ''}}">
    <label for="fechaCapacitacion" class="control-label">{{ 'Fechacapacitacion' }}</label>
    <input class="form-control" name="fechaCapacitacion" type="text" id="fechaCapacitacion" value="{{ isset($persona->fechaCapacitacion) ? $persona->fechaCapacitacion : ''}}" >
    {!! $errors->first('fechaCapacitacion', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('descripcion') ? 'has-error' : ''}}">
    <label for="descripcion" class="control-label">{{ 'Descripcion' }}</label>
    <input class="form-control" name="descripcion" type="text" id="descripcion" value="{{ isset($persona->descripcion) ? $persona->descripcion : ''}}" >
    {!! $errors->first('descripcion', '<p class="help-block">:message</p>') !!}
</div>


<div class="form-group">
    <input class="btn btn-primary" type="submit" value="{{ $formMode === 'edit' ? 'Update' : 'Create' }}">
</div>
