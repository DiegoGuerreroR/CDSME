<div class="form-group">
    <label for="">CCT</label>
    <select name="id" id="id" class="form-control">
    <option value="">-- Elegir CCT ---</option>
    @foreach($item as $item)

        <option value="{{ $item['id'] }}">{{ $item['cct'] }}</option>

    @endforeach
    </select>
</div>

<div class="form-group {{ $errors->has('dispositivo') ? 'has-error' : ''}}">
    <label for="dispositivo" class="control-label">{{ 'Dispositivo' }}</label>
    <input class="form-control" name="dispositivo" type="text" id="dispositivo" value="{{ isset($dispositivo->dispositivo) ? $dispositivo->dispositivo : ''}}" placeholder="Ingeresa Dispositivo" >
    {!! $errors->first('dispositivo', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('modelo') ? 'has-error' : ''}}">
    <label for="modelo" class="control-label">{{ 'Modelo' }}</label>
    <input class="form-control" name="modelo" type="text" id="modelo" value="{{ isset($dispositivo->modelo) ? $dispositivo->modelo : ''}}" placeholder="Ingeresa Modelo" >
    {!! $errors->first('modelo', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('estatus') ? 'has-error' : ''}}">
    <label for="estatus" class="control-label">{{ 'Estatus' }}</label>
    <input class="form-control" name="estatus" type="text" id="estatus" value="{{ isset($dispositivo->estatus) ? $dispositivo->estatus : ''}}" placeholder="Ingeresa Estatus" >
    {!! $errors->first('estatus', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('fechaEntrada') ? 'has-error' : ''}}">
    <label for="fechaEntrada" class="control-label">{{ 'Fecha Entrada' }}</label>
    <input class="form-control" name="fechaEntrada" type="date" id="fechaEntrada" value="{{ isset($dispositivo->fechaEntrada) ? $dispositivo->fechaEntrada : ''}}" placeholder="Ingeresa Fecha de Entrada" >
    {!! $errors->first('fechaEntrada', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('fechaSalida') ? 'has-error' : ''}}">
    <label for="fechaSalida" class="control-label">{{ 'Fecha Salida' }}</label>
    <input class="form-control" name="fechaSalida" type="date" id="fechaSalida" value="{{ isset($dispositivo->fechaSalida) ? $dispositivo->fechaSalida : ''}}" placeholder="Ingeresa Fecha de Salida >
    {!! $errors->first('fechaSalida', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('descripcion') ? 'has-error' : ''}}">
    <label for="descripcion" class="control-label">{{ 'Descripcion' }}</label>
    <input class="form-control" name="descripcion" type="text" id="descripcion" value="{{ isset($dispositivo->descripcion) ? $dispositivo->descripcion : ''}}" placeholder="Ingeresa Descricpion" >
    {!! $errors->first('descripcion', '<p class="help-block">:message</p>') !!}
</div>


<div class="form-group">
    <input class="btn btn-primary" type="submit" value="{{ $formMode === 'edit' ? 'Update' : 'Create' }}">
</div>
