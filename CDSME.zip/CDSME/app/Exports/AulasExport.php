<?php

namespace App\Exports;

use App\Aula;
use Maatwebsite\Excel\Concerns\FromCollection;

class AulasExport implements FromCollection
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        return Aula::select("id", "cct", "fechaSolicitud", "fechaRehabilitacion", "estatus", "descripcion", "informacion_id")->get();
    }
}
