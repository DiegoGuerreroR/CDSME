<div class="form-group {{ $errors->has('cct') ? 'has-error' : ''}}">
    <label for="cct" class="control-label">{{ 'cct' }}</label>
    <input class="form-control" name="cct" type="text" id="cct" value="{{ isset($aula->cct) ? $aula->cct : ''}}" placeholder="Ingeresa CCT" required autofocus >
    {!! $errors->first('cct', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('fechaSolicitud') ? 'has-error' : ''}}">
    <label for="fechaSolicitud" class="control-label">{{ 'Fecha Solicitud' }}</label>
    <input class="form-control" name="fechaSolicitud" type="date" id="fechaSolicitud" value="{{ isset($aula->fechaSolicitud) ? $aula->fechaSolicitud : ''}}" placeholder="Ingeresa Fecha de Solicitud" >
    {!! $errors->first('fechaSolicitud', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('fechaRehabilitacion') ? 'has-error' : ''}}">
    <label for="fechaRehabilitacion" class="control-label">{{ 'Fecha Rehabilitacion' }}</label>
    <input class="form-control" name="fechaRehabilitacion" type="date" id="fechaRehabilitacion" value="{{ isset($aula->fechaRehabilitacion) ? $aula->fechaRehabilitacion : ''}}" placeholder="Ingeresa Fecha de la Rehabilitacion" >
    {!! $errors->first('fechaRehabilitacion', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('estatus') ? 'has-error' : ''}}">
    <label for="estatus" class="control-label">{{ 'Estatus' }}</label>
    <!--<input class="form-control" name="estatus" type="text" id="estatus" value="{{ isset($aula->estatus) ? $aula->estatus : ''}}" placeholder="Ingeresa Estatus" >-->
    <select class="form-control" name="estatus" placeholder="Ingeresa Estatus" id="estatus"  type="text" value="{{ isset($aula->estatus) ? $aula->estatus : ''}}">
    <option >-- Elegir Estatus ---</option>
    <option class="p-3 mb-2 bg-success text-white" value="Realizado">Relizado</option>
    <option class="p-3 mb-2 bg-danger text-white" value="Pendiente">Pendiente</option>
    </select>
    {!! $errors->first('estatus', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('descripcion') ? 'has-error' : ''}}">
    <label for="descripcion" class="control-label">{{ 'Descripcion' }}</label>
    <input class="form-control" name="descripcion" type="text" id="descripcion" value="{{ isset($aula->descripcion) ? $aula->descripcion : ''}}" placeholder="Ingeresa Descripcion" >
    {!! $errors->first('descripcion', '<p class="help-block">:message</p>') !!}
</div>


<div class="form-group">
    <input class="btn btn-primary" type="submit" value="{{ $formMode === 'edit' ? 'Update' : 'Create' }}">
</div>
