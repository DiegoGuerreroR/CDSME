<div class="form-group">
    <label for="">CCT</label>
    <select name="id" id="id" class="form-control" name="cct" type="text" id="cct" value="<?php echo e(isset($actividade->cct) ? $actividade->cct : ''); ?>">
    <option value="">-- Elegir CCT ---</option>
    <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <option value="<?php echo e($item['id']); ?>"><?php echo e($item['cct']); ?></option>
        

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    
</div>

<!--<div class="form-group <?php echo e($errors->has('cct') ? 'has-error' : ''); ?>">
    <label for="fecha" class="control-label"><?php echo e('cct'); ?></label>
    <input class="form-control" name="cct" type="text" id="cct" value="<?php echo e(isset($actividade->cct) ? $actividade->cct : ''); ?>" placeholder="Ingeresa cct" >
    <?php echo $errors->first('cct', '<p class="help-block">:message</p>'); ?>

</div>-->

<div class="form-group <?php echo e($errors->has('fecha') ? 'has-error' : ''); ?>">
    <label for="fecha" class="control-label"><?php echo e('Fecha'); ?></label>
    <input class="form-control" name="fecha" type="date" id="fecha" value="<?php echo e(isset($actividade->fecha) ? $actividade->fecha : ''); ?>" placeholder="Ingeresa Fecha" >
    <?php echo $errors->first('fecha', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('actividad') ? 'has-error' : ''); ?>">
    <label for="actividad" class="control-label"><?php echo e('Actividad'); ?></label>
    <input class="form-control" name="actividad" type="text" id="actividad" value="<?php echo e(isset($actividade->actividad) ? $actividade->actividad : ''); ?>" placeholder="Ingeresa Actividad" >
    <?php echo $errors->first('actividad', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group">
    <input class="btn btn-primary" type="submit" value="<?php echo e($formMode === 'edit' ? 'Update' : 'Create'); ?>">
</div>
