<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateAulasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('aulas', function (Blueprint $table) {
            $table->increments('id');
            $table->string('cct');
            $table->string('fechaSolicitud')->nullable();
            $table->string('fechaRehabilitacion')->nullable();
            $table->string('estatus')->nullable();
            $table->string('descripcion')->nullable();
            $table->timestamps();
            $table->integer('informacion_id')->unsigned();

            $table->foreign('informacion_id')->references('id')->on('informacions');
            });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('aulas');
    }
}
