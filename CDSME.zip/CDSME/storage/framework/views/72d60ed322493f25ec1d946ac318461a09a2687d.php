<div class="form-group <?php echo e($errors->has('fecha') ? 'has-error' : ''); ?>">
    <label for="fecha" class="control-label"><?php echo e('Fecha'); ?></label>
    <input class="form-control" name="fecha" type="date" id="fecha" value="<?php echo e(isset($actividade->fecha) ? $actividade->fecha : ''); ?>" >
    <?php echo $errors->first('fecha', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('actividad') ? 'has-error' : ''); ?>">
    <label for="actividad" class="control-label"><?php echo e('Actividad'); ?></label>
    <input class="form-control" name="actividad" type="text" id="actividad" value="<?php echo e(isset($actividade->actividad) ? $actividade->actividad : ''); ?>" >
    <?php echo $errors->first('actividad', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group">
    <input class="btn btn-primary" type="submit" value="<?php echo e($formMode === 'edit' ? 'Update' : 'Create'); ?>">
</div>
