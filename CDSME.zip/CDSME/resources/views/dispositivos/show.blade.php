@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row">
            @include('admin.sidebar')

            <div class="col-md-9">
                <div class="card">
                    <div class="card-header">Dispositivo {{ $dispositivo->id }}</div>
                    <div class="card-body">

                        <a href="{{ url('/dispositivos') }}" title="Back"><button class="btn btn-warning btn-sm"><i class="fa fa-arrow-left" aria-hidden="true"></i>Regresar</button></a>
                        <a href="{{ url('/dispositivos/' . $dispositivo->id . '/edit') }}" title="Edit Dispositivo"><button class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i>Actualizar</button></a>

                        <form method="POST" action="{{ url('dispositivos' . '/' . $dispositivo->id) }}" accept-charset="UTF-8" style="display:inline">
                            {{ method_field('DELETE') }}
                            {{ csrf_field() }}
                            <button type="submit" class="btn btn-danger btn-sm" title="Delete Dispositivo" onclick="return confirm(&quot;Confirm delete?&quot;)"><i class="fa fa-trash-o" aria-hidden="true"></i>Eliminar</button>
                        </form>
                        <br/>
                        <br/>

                        <div class="table-responsive">
                            <table class="table">
                                <tbody>
                                    <tr>
                                        <th>ID</th><td>{{ $dispositivo->id }}</td>
                                    </tr>
                                    <tr><th> CCT </th><td> {{ $dispositivo->cct }} </td></tr>
                                    <tr><th> DISPOSITIVOS </th><td> {{ $dispositivo->dispositivo }} </td></tr>
                                    <tr><th> MODELO </th><td> {{ $dispositivo->modelo }} </td></tr>
                                    <tr><th> ESTATUS </th><td> {{ $dispositivo->estatus }} </td></tr>
                                    <tr><th> FECHA ENTRADA </th><td> {{ $dispositivo->fechaEntrada }} </td></tr>
                                    <tr><th> FECHA SALIDA </th><td> {{ $dispositivo->fechaSalida }} </td></tr>
                                    <tr><th> DESCRIPCION </th><td> {{ $dispositivo->descripcion }} </td></tr>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
