<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Reporte de actividades</title>
</head>
<body>
<table>
                                <thead>
                                
                                    <tr>
                                        <th>#</th>
                                        <th>CCT</th>
                                        <th>NOMBRE</th>
                                        <th>CAPACITACION</th>
                                        <th>FECHA CAPACITACION</th>
                                        <th>DESCRICPION</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $personas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($item->cct); ?></td>
                                        <td><?php echo e($item->nombre); ?></td>
                                        <td><?php echo e($item->capacitacion); ?></td>
                                        <td><?php echo e($item->fechaCapacitacion); ?></td>
                                        <td><?php echo e($item->descripcion); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
</body>
</html>