<div class="form-group">
    <label for="">CCT</label>
    <select name="id" id="id" class="form-control">
    <option value="">-- Elegir CCT ---</option>
    <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <option value="<?php echo e($item['id']); ?>"><?php echo e($item['cct']); ?></option>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<div class="form-group <?php echo e($errors->has('fecha') ? 'has-error' : ''); ?>">
    <label for="fecha" class="control-label"><?php echo e('Fecha'); ?></label>
    <input class="form-control" name="fecha" type="date" id="fecha" value="<?php echo e(isset($escuela->fecha) ? $escuela->fecha : ''); ?>"  >
    <?php echo $errors->first('fecha', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('valoracion') ? 'has-error' : ''); ?>">
    <label for="valoracion" class="control-label"><?php echo e('Valoracion'); ?></label>
    <input class="form-control" name="valoracion" type="text" id="valoracion" value="<?php echo e(isset($escuela->valoracion) ? $escuela->valoracion : ''); ?>" placeholder="Selecciona Valoracion" >
    <?php echo $errors->first('valoracion', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('descripcion') ? 'has-error' : ''); ?>">
    <label for="descripcion" class="control-label"><?php echo e('Descripcion'); ?></label>
    <input class="form-control" name="descripcion" type="text" id="descripcion" value="<?php echo e(isset($escuela->descripcion) ? $escuela->descripcion : ''); ?>"placeholder="Ingeresa Descripcion" >
    <?php echo $errors->first('descripcion', '<p class="help-block">:message</p>'); ?>

</div>


<div class="form-group">
    <input class="btn btn-primary" type="submit" value="<?php echo e($formMode === 'edit' ? 'Update' : 'Create'); ?>">
</div>
