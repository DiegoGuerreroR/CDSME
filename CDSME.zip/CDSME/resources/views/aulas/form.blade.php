<div class="form-group {{ $errors->has('fechaSolicitud') ? 'has-error' : ''}}">
    <label for="fechaSolicitud" class="control-label">{{ 'Fechasolicitud' }}</label>
    <input class="form-control" name="fechaSolicitud" type="text" id="fechaSolicitud" value="{{ isset($aula->fechaSolicitud) ? $aula->fechaSolicitud : ''}}" >
    {!! $errors->first('fechaSolicitud', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('fechaRehabilitacion') ? 'has-error' : ''}}">
    <label for="fechaRehabilitacion" class="control-label">{{ 'Fecharehabilitacion' }}</label>
    <input class="form-control" name="fechaRehabilitacion" type="text" id="fechaRehabilitacion" value="{{ isset($aula->fechaRehabilitacion) ? $aula->fechaRehabilitacion : ''}}" >
    {!! $errors->first('fechaRehabilitacion', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('estatus') ? 'has-error' : ''}}">
    <label for="estatus" class="control-label">{{ 'Estatus' }}</label>
    <input class="form-control" name="estatus" type="text" id="estatus" value="{{ isset($aula->estatus) ? $aula->estatus : ''}}" >
    {!! $errors->first('estatus', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('descripcion') ? 'has-error' : ''}}">
    <label for="descripcion" class="control-label">{{ 'Descripcion' }}</label>
    <input class="form-control" name="descripcion" type="text" id="descripcion" value="{{ isset($aula->descripcion) ? $aula->descripcion : ''}}" >
    {!! $errors->first('descripcion', '<p class="help-block">:message</p>') !!}
</div>


<div class="form-group">
    <input class="btn btn-primary" type="submit" value="{{ $formMode === 'edit' ? 'Update' : 'Create' }}">
</div>
