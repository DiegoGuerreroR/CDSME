<div class="form-group {{ $errors->has('cct') ? 'has-error' : ''}}">
    <label for="cct" class="control-label">{{ 'cct' }}</label>
    <input class="form-control" name="cct" type="text" id="cct" value="{{ isset($escuela->cct) ? $escuela->cct : ''}}" placeholder="Ingeresa CCT" >
    {!! $errors->first('cct', '<p class="help-block">:message</p>') !!}
</div>

<div class="form-group {{ $errors->has('fecha') ? 'has-error' : ''}}">
    <label for="fecha" class="control-label">{{ 'Fecha' }}</label>
    <input class="form-control" name="fecha" type="date" id="fecha" value="{{ isset($escuela->fecha) ? $escuela->fecha : ''}}"  >
    {!! $errors->first('fecha', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('valoracion') ? 'has-error' : ''}}">
    <label for="valoracion" class="control-label">{{ 'Valoracion' }}</label>
    <input class="form-control" name="valoracion" type="text" id="valoracion" value="{{ isset($escuela->valoracion) ? $escuela->valoracion : ''}}" placeholder="Inserta el tipo de Escuela" >
    {!! $errors->first('valoracion', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('descripcion') ? 'has-error' : ''}}">
    <label for="descripcion" class="control-label">{{ 'Descripcion' }}</label>
    <input class="form-control" name="descripcion" type="text" id="descripcion" value="{{ isset($escuela->descripcion) ? $escuela->descripcion : ''}}"placeholder="Ingeresa Descripcion" >
    {!! $errors->first('descripcion', '<p class="help-block">:message</p>') !!}
</div>


<div class="form-group">
    <input class="btn btn-primary" type="submit" value="{{ $formMode === 'edit' ? 'Update' : 'Create' }}">
</div>
